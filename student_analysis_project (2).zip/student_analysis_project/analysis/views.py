import pandas as pd
import numpy as np
import json
from django.shortcuts import render
from django.http import JsonResponse
import os

def load_data():
    """Load and clean the student performance data"""
    # Update this path to your CSV file location
    csv_path = 'student_performance.csv'
    df = pd.read_csv(csv_path)
    
    # Strip whitespace from column names
    df.columns = df.columns.str.strip()
    
    return df

def dashboard(request):
    """Main dashboard view with all statistics and visualizations"""
    df = load_data()
    
    # Basic Statistics
    total_students = len(df)
    avg_total_score = df['TotalScore(100)'].mean()
    avg_attendance = df['Attendance(%)'].mean()
    avg_study_hours = df['StudyHoursPerWeek'].mean()
    
    # Grade Distribution
    grade_dist = df['Grade'].value_counts().sort_index().to_dict()
    
    # Gender Distribution
    gender_dist = df['Gender'].value_counts().to_dict()
    
    # Semester Distribution
    semester_dist = df['Semester'].value_counts().sort_index().to_dict()
    
    # Extra Curricular Impact
    extra_curr_stats = df.groupby('ExtraCurricular')['TotalScore(100)'].agg(['mean', 'count']).to_dict('index')
    
    # Performance by Gender
    gender_performance = df.groupby('Gender')['TotalScore(100)'].mean().to_dict()
    
    # Attendance vs Score (binned) - FIXED: Added .copy()
    df_temp = df.dropna(subset=['Attendance(%)', 'TotalScore(100)']).copy()
    attendance_bins = [0, 70, 80, 90, 100]
    attendance_labels = ['<70%', '70-80%', '80-90%', '90-100%']
    df_temp['AttendanceGroup'] = pd.cut(df_temp['Attendance(%)'], bins=attendance_bins, labels=attendance_labels)
    attendance_score = df_temp.groupby('AttendanceGroup', observed=True)['TotalScore(100)'].mean().to_dict()
    
    # Study Hours vs Score (binned)
    study_bins = [0, 5, 10, 15, 20]
    study_labels = ['0-5h', '5-10h', '10-15h', '15-20h']
    df_temp['StudyGroup'] = pd.cut(df_temp['StudyHoursPerWeek'], bins=study_bins, labels=study_labels)
    study_score = df_temp.groupby('StudyGroup', observed=True)['TotalScore(100)'].mean().to_dict()
    
    # Top Performers
    top_students = df.nlargest(10, 'TotalScore(100)')[['StudentID', 'Name', 'TotalScore(100)', 'Grade']].to_dict('records')
    
    # Internal Exam Statistics
    internal1_avg = df['Internal1(30)'].mean()
    internal2_avg = df['Internal2(30)'].mean()
    project_avg = df['Project(20)'].mean()
    final_exam_avg = df['FinalExam(100)'].mean()
    
    # Age Distribution
    age_dist = df['Age'].value_counts().sort_index().to_dict()
    
    # Correlation Analysis - FIXED: Apply abs() to correlation values
    numeric_cols = ['Attendance(%)', 'Internal1(30)', 'Internal2(30)', 
                    'Project(20)', 'FinalExam(100)', 'StudyHoursPerWeek', 'TotalScore(100)']
    correlation_data_raw = df[numeric_cols].corr()['TotalScore(100)'].drop('TotalScore(100)').to_dict()
    
    # Apply absolute value to correlations for display
    correlation_data = {key: abs(value) for key, value in correlation_data_raw.items()}
    
    context = {
        'total_students': total_students,
        'avg_total_score': round(avg_total_score, 2),
        'avg_attendance': round(avg_attendance, 2),
        'avg_study_hours': round(avg_study_hours, 2),
        'grade_dist': grade_dist,
        'gender_dist': gender_dist,
        'semester_dist': semester_dist,
        'extra_curr_stats': extra_curr_stats,
        'gender_performance': gender_performance,
        'attendance_score': attendance_score,
        'study_score': study_score,
        'top_students': top_students,
        'internal1_avg': round(internal1_avg, 2),
        'internal2_avg': round(internal2_avg, 2),
        'project_avg': round(project_avg, 2),
        'final_exam_avg': round(final_exam_avg, 2),
        'age_dist': age_dist,
        'correlation_data': correlation_data,
    }
    
    return render(request, 'analysis/dashboard.html', context)

def detailed_stats(request):
    """Detailed statistics view"""
    df = load_data()
    
    # Statistical summary for numeric columns
    numeric_cols = ['Age', 'Attendance(%)', 'Internal1(30)', 'Internal2(30)', 
                    'Project(20)', 'FinalExam(100)', 'StudyHoursPerWeek', 'TotalScore(100)']
    
    stats_summary = {}
    for col in numeric_cols:
        stats_summary[col] = {
            'mean': round(df[col].mean(), 2),
            'median': round(df[col].median(), 2),
            'std': round(df[col].std(), 2),
            'min': round(df[col].min(), 2),
            'max': round(df[col].max(), 2),
            'q25': round(df[col].quantile(0.25), 2),
            'q75': round(df[col].quantile(0.75), 2),
        }
    
    context = {
        'stats_summary': stats_summary,
    }
    
    return render(request, 'analysis/detailed_stats.html', context)

def student_list(request):
    """View to display student list with filtering"""
    df = load_data()
    
    # Get filter parameters
    grade_filter = request.GET.get('grade', None)
    gender_filter = request.GET.get('gender', None)
    semester_filter = request.GET.get('semester', None)
    
    # Apply filters
    if grade_filter:
        df = df[df['Grade'] == grade_filter]
    if gender_filter:
        df = df[df['Gender'] == gender_filter]
    if semester_filter:
        df = df[df['Semester'] == int(semester_filter)]
    
    # Convert to list of dictionaries
    df_display = df.rename(columns={
    'Attendance(%)': 'Attendance',
    'Internal1(30)': 'Internal1',
    'Internal2(30)': 'Internal2',
    'Project(20)': 'Project',
    'FinalExam(100)': 'FinalExam',
    'TotalScore(100)': 'TotalScore'
})

# Convert to list of dictionaries
    students = df_display.to_dict('records')
    
    # Get unique values for filters
    all_grades = sorted(load_data()['Grade'].dropna().unique())
    all_genders = sorted(load_data()['Gender'].unique())
    all_semesters = sorted(load_data()['Semester'].unique())
    
    context = {
        'students': students,
        'all_grades': all_grades,
        'all_genders': all_genders,
        'all_semesters': all_semesters,
        'current_grade': grade_filter,
        'current_gender': gender_filter,
        'current_semester': semester_filter,
    }
    
    return render(request, 'analysis/student_list.html', context)