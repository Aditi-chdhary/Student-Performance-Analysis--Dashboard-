from django.urls import path
from . import views

app_name = 'analysis'

urlpatterns = [
    path('', views.dashboard, name='dashboard'),
    path('stats/', views.detailed_stats, name='detailed_stats'),
    path('students/', views.student_list, name='student_list'),
]